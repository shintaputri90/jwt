const { verifyToken } = require('../utils/tokenManager');

function authMiddleware(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }

    try {
        req.user = verifyToken(token.split(' ')[1]);
        next();
    } catch (err) {
        res.status(403).json({ message: err.message });
    }
}

module.exports = authMiddleware;
