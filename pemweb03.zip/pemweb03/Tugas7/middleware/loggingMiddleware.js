const fs = require('fs');

function loggingMiddleware(req, res, next) {
    const logEntry = {
        method: req.method,
        endpoint: req.originalUrl,
        user: req.user || 'Unauthenticated',
        timestamp: new Date().toISOString(),
    };

    fs.appendFileSync('./access.log', JSON.stringify(logEntry) + '\n');
    next();
}

module.exports = loggingMiddleware;
