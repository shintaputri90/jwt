const fs = require('fs');

// Load revoked tokens on server start
let revokedTokens = [];
if (fs.existsSync('./revokedTokens.json')) {
    revokedTokens = JSON.parse(fs.readFileSync('./revokedTokens.json'));
}

module.exports = revokedTokens;

