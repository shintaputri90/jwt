const jwt = require('jsonwebtoken');
const fs = require('fs');

// In-memory revoked tokens store
const revokedTokens = [];

// Generate JWT
function generateToken(payload) {
    const token = jwt.sign(payload, process.env.SECRET_KEY, { expiresIn: '1h' });
    return token;
}

// Verify JWT
function verifyToken(token) {
    try {
        const decoded = jwt.verify(token, process.env.SECRET_KEY);
        if (revokedTokens.includes(token)) throw new Error('Token is revoked');
        return decoded;
    } catch (err) {
        throw new Error('Invalid or expired token');
    }
}

// Revoke JWT
function revokeToken(token) {
    revokedTokens.push(token);
}

// Persist revoked tokens (optional, for larger systems)
function persistRevokedTokens() {
    fs.writeFileSync('./models/revokedTokens.json', JSON.stringify(revokedTokens));
}

module.exports = { generateToken, verifyToken, revokeToken, persistRevokedTokens };
