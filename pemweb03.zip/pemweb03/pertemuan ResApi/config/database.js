const mysql = require("mysql");

const koneksi = mysql.createConnection({
    host: "localhost", 
    user: "root", 
    password: "", 
    database: "latihanrestapi"  
});

koneksi.connect((err) => {
    if (err) {
        console.error("Error connecting to MySQL:", err.message); 
        return; 
    }
    console.log("MySQL Connected...");
});


module.exports = koneksi;