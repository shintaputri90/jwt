const express = require('express');
const bodyParser = require('body-parser');
const koneksi = require('./config/database');
const app = express();
const PORT = process.env.PORT || 3000;

//set body parser 
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));       

//create data / insert data 
app.post('/api/latihanrestapi', (req, res) => {
    //buat variable penampung data dan query sql 
    const data = {...req.body};
    const querySql = 'INSERT INTO latihanrestapi SET ?';

    //jalankan  query 
    koneksi.query(querySql, data, (err, rows, fields) => {
        //error handling 
        if(err) {
            return res.status(500).json({ message: 'Gagal insert data!', error: err });
        }

        //jika request berhasil
        res.status(201).json({ success: true, message: 'Data berhasil disimpan!' });
    });
});







//buat server nya 
app.listen(PORT, () => 
    console.log(`Server running at port:${PORT}`));